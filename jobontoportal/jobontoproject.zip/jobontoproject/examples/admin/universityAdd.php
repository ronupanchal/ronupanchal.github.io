<?php 
set_include_path(get_include_path() . PATH_SEPARATOR . '../lib/');
    require_once "EasyRdf.php";
    require_once "html_tag_helpers.php";
	
	// Setup some additional prefixes for DBpedia
    EasyRdf_Namespace::set('rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');
    EasyRdf_Namespace::set('owl', 'http://www.w3.org/2002/07/owl#');
    EasyRdf_Namespace::set('my', 'https://drronakpanchal.wordpress.com/');
    //EasyRdf_Namespace::set('dbp', 'http://dbpedia.org/property/');
$endpoint = new EasyRdf_Sparql_Client('http://localhost:3030/Uni/query','http://localhost:3030/Uni/update');
	

if(isset($_POST['uniadd']))//Add record
{
	//echo "hi";
	
	$ucode=$_POST['unicode'];
	$uname=strtoupper($_POST['uniname']);
	//echo $ucode.$uname;
	 //$insertarea = "INSERT INTO panchal_samaj_areas (AREA) VALUES ('".$area."')";
	 
	 $result = $endpoint->update("insert data".
	" { ".
		 "my:Uni".$ucode." rdf:type my:University . ".
         "my:Uni".$ucode." rdf:type owl:NamedIndividual . ".
		 "my:Uni".$ucode." my:nameOfUni '".$uname."' . ".
		 "my:Uni".$ucode." my:codeOfUni ".$ucode." . ".
    "}"
    );
	 
	//mysql_query($insertarea);
	//======================================================================================   
	
            //display success message
          if($result) {
                echo "<script>alert('Record is inserted successfully!')</script>";
          		echo "<script>window.open('university1.php','_self')</script>";
            }
 }
 ?>