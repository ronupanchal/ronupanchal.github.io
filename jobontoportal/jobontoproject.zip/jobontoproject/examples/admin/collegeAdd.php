<?php 
set_include_path(get_include_path() . PATH_SEPARATOR . '../lib/');
    require_once "EasyRdf.php";
	
	// Setup some additional prefixes for DBpedia
    EasyRdf_Namespace::set('rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');
    EasyRdf_Namespace::set('owl', 'http://www.w3.org/2002/07/owl#');
    EasyRdf_Namespace::set('my', 'https://drronakpanchal.wordpress.com/');
    //EasyRdf_Namespace::set('dbp', 'http://dbpedia.org/property/');
$endpoint = new EasyRdf_Sparql_Client('http://localhost:3030/Uni/query','http://localhost:3030/Uni/update');
	

if(isset($_POST['collegeadd']))//Add record
{
	
	
	$ccode=$_POST['instcode'];
	$cname=strtoupper($_POST['instname']);
	
	 //$insertarea = "INSERT INTO panchal_samaj_areas (AREA) VALUES ('".$area."')";
	 
	 $result = $endpoint->update("insert data".
	" { ".
		 "my:COLLEGE".$ccode." rdf:type my:Institution . ".
         "my:COLLEGE".$ccode." rdf:type owl:NamedIndividual . ".
		 "my:COLLEGE".$ccode." my:nameOfInstitution '".$cname."' . ".
		 "my:COLLEGE".$ccode." my:codeOfInstitution ".$ccode." . ".
		 "my:Institution rdf:subClassOf"
    "}"
    );
	 
	//mysql_query($insertarea);
	//======================================================================================   
	
            //display success message
          if($result) {
                echo "<script>alert('Record is inserted successfully!')</script>";
          		echo "<script>window.open('college_list.php','_self')</script>";
            }
 }
 ?>