<?php 
 include("header.php");
 include("menu.php");
 
  set_include_path(get_include_path() . PATH_SEPARATOR . '../lib/');
    require_once "EasyRdf.php";
    require_once "html_tag_helpers.php";

    // Setup some additional prefixes for DBpedia
    EasyRdf_Namespace::set('rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');
    EasyRdf_Namespace::set('owl', 'http://www.w3.org/2002/07/owl#');
    EasyRdf_Namespace::set('my', 'https://drronakpanchal.wordpress.com/');

    $sparql = new EasyRdf_Sparql_Client('http://localhost:3030/Uni/sparql');
	
	
 ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
 <script>

$(document).ready(function(){
$("#universityname").change(function() {
    var ucode = $(this).val();
	//var uname =val();
    alert("You have selected the universitycode - " + ucode );
});
});
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>General Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">General Form</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">College Detail</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="collegeAdd.php" method="post">
                <div class="card-body">
				<!-- select -->
                  <div class="form-group">
                    <label>Select</label>
                    <select class="form-control" id="universityname">
                      <option selected>---SELECT UNIVERSITY---</option>
					  <?php
    $result = $sparql->query(
             'SELECT  DISTINCT ?indv ?un ?uc WHERE  { 
  ?indv rdf:type my:University .
   ?indv my:nameOfUni ?un .
   ?indv my:codeOfUni ?uc .
} ORDER BY ?un'
    );
    foreach ($result as $row) {
        echo "<option value=".$row->uc.">".link_to($row->un, $row->indv)."</option>";
    }
	
	
?>
                     
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Institution or College Code</label>
                    <input type="text" class="form-control" name="instcode" placeholder="Enter Institution or College Code">
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Institution or College Name</label>
                    <input type="text" class="form-control" name="instname" placeholder="Enter Institution or College Name">
                  </div>
                 
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="collegeadd"  class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 <?php
  include("footer.php");
 ?>